mpii_data_path = '../';
